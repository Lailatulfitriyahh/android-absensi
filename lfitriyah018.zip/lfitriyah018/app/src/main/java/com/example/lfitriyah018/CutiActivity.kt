package com.example.lfitriyah018

import android.app.DatePickerDialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class CutiActivity : AppCompatActivity() {

    private lateinit var container: LinearLayout
    private lateinit var etMulai: EditText
    private lateinit var etSelesai: EditText

    // Calendar untuk menyimpan tanggal yang dipilih
    private val calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cuti)

        val spinner = findViewById<Spinner>(R.id.spinnerJenisCuti)
        etMulai = findViewById(R.id.etMulaiCuti)
        etSelesai = findViewById(R.id.etSelesaiCuti)
        val etAlasan = findViewById<EditText>(R.id.etAlasanCuti)
        val btnKirim = findViewById<Button>(R.id.btnKirimCuti)
        container = findViewById(R.id.containerCutiList)

        // 1. Setup Spinner (Daftar Pilihan Cuti)
        val opsiCuti = arrayOf("Cuti Tahunan", "Cuti Melahirkan", "Cuti Menikah", "Cuti Penting", "Cuti Sakit")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opsiCuti)
        spinner.adapter = adapter

        // 2. Setup Kalender (DatePicker)
        // Saat kolom Mulai diklik
        etMulai.setOnClickListener {
            showDatePicker(etMulai)
        }

        // Saat kolom Selesai diklik
        etSelesai.setOnClickListener {
            showDatePicker(etSelesai)
        }

        // 3. Load Data Lama (Riwayat)
        loadData()

        // 4. Tombol Kirim
        btnKirim.setOnClickListener {
            val jenis = spinner.selectedItem.toString()
            val mulai = etMulai.text.toString()
            val selesai = etSelesai.text.toString()
            val alasan = etAlasan.text.toString()

            if (mulai.isEmpty() || selesai.isEmpty() || alasan.isEmpty()) {
                Toast.makeText(this, "Mohon lengkapi data!", Toast.LENGTH_SHORT).show()
            } else {
                saveData(jenis, mulai, selesai, alasan)

                // Reset Form
                etMulai.text.clear()
                etSelesai.text.clear()
                etAlasan.text.clear()

                // Refresh List
                container.removeAllViews()
                loadData()

                Toast.makeText(this, "Pengajuan Cuti Tersimpan!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Fungsi menampilkan Popup Kalender
    private fun showDatePicker(editText: EditText) {
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                // Format tanggal yang dipilih (misal: 28/12/2025)
                // Note: selectedMonth dimulai dari 0, jadi perlu +1
                val selectedDate = "$selectedDay/${selectedMonth + 1}/$selectedYear"
                editText.setText(selectedDate)
            },
            year,
            month,
            day
        )
        datePickerDialog.show()
    }

    private fun saveData(jenis: String, mulai: String, selesai: String, alasan: String) {
        // Format Simpan: JENIS|MULAI|SELESAI|ALASAN
        val newData = "$jenis|$mulai|$selesai|$alasan"

        val pref = getSharedPreferences("CUTI_DATA", Context.MODE_PRIVATE)
        val oldData = pref.getString("LIST_CUTI", "")

        val fixData = if (oldData.isNullOrEmpty()) newData else "$newData;$oldData"
        pref.edit().putString("LIST_CUTI", fixData).apply()
    }

    private fun loadData() {
        val pref = getSharedPreferences("CUTI_DATA", Context.MODE_PRIVATE)
        val allData = pref.getString("LIST_CUTI", "")

        if (!allData.isNullOrEmpty()) {
            val items = allData.split(";")
            for (item in items) {
                if (item.isNotEmpty()) {
                    val parts = item.split("|")
                    if (parts.size >= 4) {
                        val jenis = parts[0]
                        val mulai = parts[1]
                        val selesai = parts[2]
                        val alasan = parts[3]

                        addCard(jenis, mulai, selesai, alasan)
                    }
                }
            }
        }
    }

    private fun addCard(jenis: String, mulai: String, selesai: String, alasan: String) {
        val view = LayoutInflater.from(this).inflate(R.layout.item_cuti, container, false)

        val tvJenis = view.findViewById<TextView>(R.id.tvItemJenisCuti)
        val tvTgl = view.findViewById<TextView>(R.id.tvItemTanggalCuti)
        val tvAlasan = view.findViewById<TextView>(R.id.tvItemAlasanCuti)

        tvJenis.text = jenis.uppercase()
        tvTgl.text = "$mulai s/d $selesai"
        tvAlasan.text = alasan

        container.addView(view)
    }
}
