package com.example.lfitriyah018

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap // <--- INI YANG BENAR
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.lfitriyah018.databinding.ActivityAbsenBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*


class AbsenActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAbsenBinding
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val REQUEST_CODE_PERMISSIONS = 101
    private val REQUEST_CODE_CAMERA = 102
    private var isCheckIn = true // True = Masuk, False = Keluar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAbsenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Terima data dari Dashboard (IN atau OUT)
        isCheckIn = intent.getBooleanExtra("IS_CHECK_IN", true)
        binding.tvTitle.text = if (isCheckIn) "Absen Masuk" else "Absen Keluar"

        // Setup Lokasi
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        // Cek Izin Kamera & Lokasi saat buka halaman
        if (checkPermissions()) {
            getCurrentLocation()
        } else {
            requestPermissions()
        }

        binding.btnCapture.setOnClickListener {
            // Buka Kamera
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            if (cameraIntent.resolveActivity(packageManager) != null) {
                startActivityForResult(cameraIntent, REQUEST_CODE_CAMERA)
            } else {
                Toast.makeText(this, "Kamera tidak tersedia", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Mendapatkan Lokasi Terkini
    @SuppressLint("MissingPermission")
    private fun getCurrentLocation() {
        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            if (location != null) {
                // Lokasi didapat (Latitude, Longitude)
                val lat = location.latitude
                val long = location.longitude

                // Ubah koordinat jadi Alamat (Geocoding)
                val address = getAddressName(lat, long)
                binding.tvLocation.text = address
            } else {
                binding.tvLocation.text = "Lokasi tidak ditemukan, nyalakan GPS."
            }
        }
    }

    // Fungsi mengubah Koordinat -> Nama Jalan
    private fun getAddressName(lat: Double, long: Double): String {
        val geocoder = Geocoder(this, Locale.getDefault())
        try {
            val addresses = geocoder.getFromLocation(lat, long, 1)
            if (addresses != null && addresses.isNotEmpty()) {
                return addresses[0].getAddressLine(0) // Alamat lengkap
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return "Lat: $lat, Long: $long"
    }

    // Hasil Foto Kamera & Proses Simpan
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CODE_CAMERA && resultCode == RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap
            binding.ivPhotoResult.setImageBitmap(imageBitmap)

            // --- BAGIAN BARU: SIMPAN DATA KE HISTORY ---
            saveAbsenData(imageBitmap)

            Toast.makeText(this, "Absen Berhasil & Tersimpan di History!", Toast.LENGTH_LONG).show()

            binding.btnCapture.text = "Berhasil!"
            binding.btnCapture.isEnabled = false

            // Otomatis kembali ke dashboard setelah 2 detik
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                finish()
            }, 2000)
        }
    }

    // Fungsi Menyimpan Data (Sederhana menggunakan SharedPreferences)
    private fun saveAbsenData(bitmap: Bitmap) {
        // A. Simpan Gambar ke Penyimpanan HP
        val imagePath = saveImageToInternalStorage(bitmap)

        // B. Siapkan Data Teks
        val sdfDate = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val sdfTime = SimpleDateFormat("HH:mm", Locale.getDefault())
        val currentDate = Date()

        val tanggal = sdfDate.format(currentDate)
        val jam = sdfTime.format(currentDate)
        val tipe = if (isCheckIn) "Masuk" else "Keluar"
        val lokasi = binding.tvLocation.text.toString()

        // C. Simpan String Data (Format: "Tanggal|Jam|Tipe|Lokasi|PathGambar")
        // Kita gabungkan jadi satu string panjang dipisah tanda "|"
        val dataString = "$tanggal|$jam|$tipe|$lokasi|$imagePath"

        // Simpan ke SharedPreferences (Database kecil bawaan Android)
        val sharedPref = getSharedPreferences("HISTORY_ABSEN", Context.MODE_PRIVATE)
        val editor = sharedPref.edit()

        // Ambil data lama dulu (kalau ada), lalu gabung dengan data baru
        val oldHistory = sharedPref.getString("LIST_HISTORY", "")

        // Format: DataBaru;DataLama
        val newHistory = if (oldHistory.isNullOrEmpty()) {
            dataString
        } else {
            "$dataString;$oldHistory"
        }

        editor.putString("LIST_HISTORY", newHistory)
        editor.apply()
    }

    // Fungsi Helper Simpan Gambar ke Internal Storage
    private fun saveImageToInternalStorage(bitmap: Bitmap): String {
        val wrapper = android.content.ContextWrapper(applicationContext)
        var file = wrapper.getDir("Images", Context.MODE_PRIVATE)
        file = File(file, "absen_${System.currentTimeMillis()}.jpg")

        try {
            val stream: java.io.OutputStream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream)
            stream.flush()
            stream.close()
        } catch (e: java.io.IOException) {
            e.printStackTrace()
        }
        return file.absolutePath
    }

    // Cek Izin
    private fun checkPermissions(): Boolean {
        val camPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
        val locPermission = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
        return camPermission == PackageManager.PERMISSION_GRANTED && locPermission == PackageManager.PERMISSION_GRANTED
    }

    // Minta Izin
    private fun requestPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.ACCESS_FINE_LOCATION),
            REQUEST_CODE_PERMISSIONS
        )
    }

    // Hasil Permintaan Izin
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation()
            } else {
                Toast.makeText(this, "Izin diperlukan untuk absen", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
