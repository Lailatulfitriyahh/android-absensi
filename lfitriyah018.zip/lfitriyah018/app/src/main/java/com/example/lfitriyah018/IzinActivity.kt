package com.example.lfitriyah018

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class IzinActivity : AppCompatActivity() {

    private lateinit var container: LinearLayout
    private lateinit var ivPhoto: ImageView
    private var currentBitmap: Bitmap? = null
    private val REQ_CAMERA = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_izin)

        val tvDate = findViewById<TextView>(R.id.tvIzinDate)
        val rgJenis = findViewById<RadioGroup>(R.id.rgJenisIzin)
        val etAlasan = findViewById<EditText>(R.id.etAlasanIzin)
        val btnFoto = findViewById<Button>(R.id.btnAmbilFotoIzin)
        val btnKirim = findViewById<Button>(R.id.btnKirimIzin)
        ivPhoto = findViewById(R.id.ivIzinPhoto)
        container = findViewById(R.id.containerIzinList)

        // 1. Set Tanggal Hari Ini
        val sdf = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id", "ID"))
        tvDate.text = sdf.format(Date())

        // 2. Load Data Lama
        loadData()

        // 3. Tombol Ambil Foto
        btnFoto.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), REQ_CAMERA)
            } else {
                openCamera()
            }
        }

        // 4. Tombol Kirim
        btnKirim.setOnClickListener {
            val selectedId = rgJenis.checkedRadioButtonId
            val alasan = etAlasan.text.toString()

            if (selectedId == -1) {
                Toast.makeText(this, "Pilih jenis izin dulu!", Toast.LENGTH_SHORT).show()
            } else if (alasan.isEmpty()) {
                Toast.makeText(this, "Isi alasan izin!", Toast.LENGTH_SHORT).show()
            } else {
                val rbSelected = findViewById<RadioButton>(selectedId)
                val jenis = rbSelected.text.toString() // "Sakit" atau "Cuti"

                // Simpan
                saveIzin(jenis, alasan, currentBitmap)

                // Reset
                etAlasan.text.clear()
                rgJenis.clearCheck()
                ivPhoto.setImageResource(R.drawable.ic_launcher_background)
                currentBitmap = null

                // Refresh List
                container.removeAllViews()
                loadData()

                Toast.makeText(this, "Pengajuan Izin Terkirim!", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (intent.resolveActivity(packageManager) != null) {
            startActivityForResult(intent, REQ_CAMERA)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAMERA && resultCode == RESULT_OK) {
            val img = data?.extras?.get("data") as Bitmap
            currentBitmap = img
            ivPhoto.setImageBitmap(img)
        }
    }

    private fun saveIzin(jenis: String, alasan: String, bitmap: Bitmap?) {
        // Simpan gambar jika ada
        var imagePath = ""
        if (bitmap != null) {
            imagePath = saveImageToInternalStorage(bitmap)
        } else {
            imagePath = "none" // Penanda jika tidak ada foto
        }

        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val tanggal = sdf.format(Date())

        // Format: TANGGAL|JENIS|ALASAN|PATH
        val newData = "$tanggal|$jenis|$alasan|$imagePath"

        val pref = getSharedPreferences("IZIN_DATA", Context.MODE_PRIVATE)
        val oldData = pref.getString("LIST_IZIN", "")

        val fixData = if (oldData.isNullOrEmpty()) newData else "$newData;$oldData"
        pref.edit().putString("LIST_IZIN", fixData).apply()
    }

    private fun loadData() {
        val pref = getSharedPreferences("IZIN_DATA", Context.MODE_PRIVATE)
        val allData = pref.getString("LIST_IZIN", "")

        if (!allData.isNullOrEmpty()) {
            val items = allData.split(";")
            for (item in items) {
                if (item.isNotEmpty()) {
                    val parts = item.split("|")
                    if (parts.size >= 4) {
                        val tgl = parts[0]
                        val jenis = parts[1]
                        val alasan = parts[2]
                        val path = parts[3]

                        addCard(tgl, jenis, alasan, path)
                    }
                }
            }
        }
    }

    private fun addCard(tgl: String, jenis: String, alasan: String, path: String) {
        val view = LayoutInflater.from(this).inflate(R.layout.item_izin, container, false)

        val tvTgl = view.findViewById<TextView>(R.id.tvItemTanggalIzin)
        val tvJenis = view.findViewById<TextView>(R.id.tvItemJenisIzin)
        val tvAlasan = view.findViewById<TextView>(R.id.tvItemAlasan)
        val ivItem = view.findViewById<ImageView>(R.id.ivItemIzin)

        tvTgl.text = tgl
        tvJenis.text = "IZIN $jenis".uppercase()
        tvAlasan.text = alasan

        if (path != "none") {
            val imgFile = File(path)
            if (imgFile.exists()) {
                val bmp = BitmapFactory.decodeFile(imgFile.absolutePath)
                ivItem.setImageBitmap(bmp)
            }
        } else {
            // Jika tidak ada foto, set gambar default atau sembunyikan
            ivItem.setImageResource(R.drawable.ic_launcher_background)
        }

        container.addView(view)
    }

    private fun saveImageToInternalStorage(bitmap: Bitmap): String {
        val wrapper = android.content.ContextWrapper(applicationContext)
        var file = wrapper.getDir("IzinImages", Context.MODE_PRIVATE)
        file = File(file, "izin_${System.currentTimeMillis()}.jpg")
        try {
            val stream: java.io.OutputStream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
            stream.close()
        } catch (e: Exception) { e.printStackTrace() }
        return file.absolutePath
    }
}
