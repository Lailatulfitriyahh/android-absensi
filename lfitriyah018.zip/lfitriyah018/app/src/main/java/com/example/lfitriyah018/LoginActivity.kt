package com.example.lfitriyah018

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.lfitriyah018.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener {
            handleLogin()
        }
    }

    private fun handleLogin() {
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()

        // Validasi input kosong
        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Mohon isi Email dan Password!", Toast.LENGTH_SHORT).show()
            return
        }

        // Validasi Login (Hardcode sederhana)
        if (email == "lfitriyah" && password == "0211") {
            Toast.makeText(this, "Login Berhasil!", Toast.LENGTH_SHORT).show()

            // --- KODE PINDAH HALAMAN (INTENT) ---
            val intent = Intent(this, DashboardActivity::class.java)
            startActivity(intent)

            // Menutup LoginActivity agar user tidak bisa kembali ke login saat tekan tombol Back
            finish()
        } else {
            Toast.makeText(this, "Login Gagal. Coba user / 1234", Toast.LENGTH_SHORT).show()
        }
    }
}
