package com.example.lfitriyah018

import android.graphics.Bitmap

// Data class sederhana untuk menyimpan 1 baris riwayat
data class AbsenData(
    val tanggal: String,
    val waktu: String,
    val tipe: String, // "Masuk" atau "Keluar"
    val lokasi: String,
    val imagePath: String // Kita simpan lokasi filenya, bukan gambarnya langsung biar ringan
)
