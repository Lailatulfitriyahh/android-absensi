package com.example.lfitriyah018

import android.graphics.Color
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.CalendarView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class RekapActivity : AppCompatActivity() {

    private lateinit var tvTotalHadir: TextView
    private lateinit var tvTotalSakit: TextView
    private lateinit var tvTotalIzin: TextView
    private lateinit var tvTotalAlpha: TextView
    private lateinit var tvBulanTahun: TextView
    private lateinit var dropdownBulan: AutoCompleteTextView
    private lateinit var calendarView: CalendarView
    private lateinit var tvStatusTanggal: TextView

    // Variabel global untuk menyimpan bulan yang sedang dipilih
    private var selectedMonthName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rekap)

        // Inisialisasi View
        tvTotalHadir = findViewById(R.id.tvTotalHadir)
        tvTotalSakit = findViewById(R.id.tvTotalSakit)
        tvTotalIzin = findViewById(R.id.tvTotalIzin)
        tvTotalAlpha = findViewById(R.id.tvTotalAlpha)
        tvBulanTahun = findViewById(R.id.tvRekapBulan)
        dropdownBulan = findViewById(R.id.dropdownBulan)
        calendarView = findViewById(R.id.calendarViewRekap)
        tvStatusTanggal = findViewById(R.id.tvStatusTanggal)

        // Setup Dropdown Bulan
        setupDropdown()

        // Set Default ke Bulan Ini (Desember 2025 sesuai request)
        val defaultBulan = "Desember 2025"
        dropdownBulan.setText(defaultBulan, false)
        tvBulanTahun.text = "Periode: $defaultBulan"

        // Load Data Awal
        loadDataManipulasi(defaultBulan)
        setupCalendarInteraction()
    }

    private fun setupDropdown() {
        val bulanList = listOf(
            "Januari 2025", "Februari 2025", "Maret 2025", "April 2025",
            "Mei 2025", "Juni 2025", "Juli 2025", "Agustus 2025",
            "September 2025", "Oktober 2025", "November 2025", "Desember 2025"
        )

        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, bulanList)
        dropdownBulan.setAdapter(adapter)

        dropdownBulan.setOnItemClickListener { parent, _, position, _ ->
            val selectedBulan = parent.getItemAtPosition(position).toString()
            tvBulanTahun.text = "Periode: $selectedBulan"

            // Panggil fungsi manipulasi data setiap ganti bulan
            loadDataManipulasi(selectedBulan)

            Toast.makeText(this, "Data $selectedBulan dimuat", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadDataManipulasi(bulan: String) {
        selectedMonthName = bulan // Simpan bulan terpilih untuk logika kalender

        var hadir = 0
        var sakit = 0
        var izin = 0
        var alpha = 0

        // --- LOGIKA MANIPULASI DATA ---
        if (bulan.contains("Desember")) {
            // Skenario 1: Desember (Sakit 2, Izin 1, Alpha 0)
            sakit = 2
            izin = 1
            alpha = 0
            hadir = 22 // Sisa hari kerja (misal total 25 hari kerja)

        } else if (bulan.contains("November")) {
            // Skenario 2: November (Rajin banget, Full Hadir)
            sakit = 0
            izin = 0
            alpha = 0
            hadir = 25

        } else if (bulan.contains("Oktober")) {
            // Skenario 3: Oktober (Ada Alpha 1 hari)
            sakit = 1
            izin = 0
            alpha = 1
            hadir = 23

        } else {
            // Skenario Default untuk bulan lain
            sakit = 0
            izin = 0
            alpha = 0
            hadir = 20
        }

        // Tampilkan ke Layar Statistik
        tvTotalHadir.text = "$hadir Hari"
        tvTotalSakit.text = "$sakit Hari"
        tvTotalIzin.text = "$izin Hari"
        tvTotalAlpha.text = "$alpha Hari"
    }

    private fun setupCalendarInteraction() {
        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            // Note: Parameter 'month' dimulai dari 0 (Januari = 0, Desember = 11)

            var statusText = "Status: HADIR (Tepat Waktu)"
            var colorCode = "#2E7D32" // Hijau (Default Hadir)

            // --- LOGIKA KALENDER BERDASARKAN BULAN YANG DIPILIH ---

            if (selectedMonthName.contains("Desember")) {
                // Skenario Desember: Sakit tgl 5 & 6, Izin tgl 12
                when (dayOfMonth) {
                    5, 6 -> {
                        statusText = "Status: SAKIT (Demam)"
                        colorCode = "#1565C0" // Biru
                    }
                    12 -> {
                        statusText = "Status: IZIN (Acara Keluarga)"
                        colorCode = "#E65100" // Orange
                    }
                    // Tanggal Merah / Libur (Contoh tgl 25 Natal)
                    25 -> {
                        statusText = "Status: LIBUR NASIONAL"
                        colorCode = "#757575" // Abu-abu
                    }
                }
            }
            else if (selectedMonthName.contains("November")) {
                // Skenario November: Full Hadir (Tidak ada sakit/izin)
                // Kecuali hari minggu (logika sederhana aja)
                if (dayOfMonth % 7 == 0) {
                    statusText = "Status: LIBUR AKHIR PEKAN"
                    colorCode = "#757575"
                }
            }
            else if (selectedMonthName.contains("Oktober")) {
                // Skenario Oktober: Alpha tgl 10
                if (dayOfMonth == 10) {
                    statusText = "Status: ALPHA (Tanpa Keterangan)"
                    colorCode = "#B71C1C" // Merah
                }
            }

            // Update Teks dan Warna
            tvStatusTanggal.text = "Tanggal $dayOfMonth $selectedMonthName: $statusText"
            tvStatusTanggal.setTextColor(Color.parseColor(colorCode))
        }
    }
}
