package com.example.lfitriyah018

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
class KehadiranManualActivity : AppCompatActivity() {

    private lateinit var tvDate: TextView
    private lateinit var tvLoc: TextView
    private lateinit var ivPhoto: ImageView
    private lateinit var etKet: EditText
    private lateinit var btnFoto: Button
    private lateinit var btnSimpan: Button
    private lateinit var container: LinearLayout

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var currentPhotoBitmap: Bitmap? = null
    private val REQ_CAMERA = 101
    private val REQ_PERMISSION = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kehadiran_manual)

        tvDate = findViewById(R.id.tvManualDate)
        tvLoc = findViewById(R.id.tvManualLoc)
        ivPhoto = findViewById(R.id.ivManualPhoto)
        etKet = findViewById(R.id.etManualKet)
        btnFoto = findViewById(R.id.btnAmbilFotoManual)
        btnSimpan = findViewById(R.id.btnSimpanManual)
        container = findViewById(R.id.containerManualList)

        // Set Tanggal
        val sdf = SimpleDateFormat("EEEE, dd MMMM yyyy - HH:mm", Locale("id", "ID"))
        tvDate.text = sdf.format(Date())

        // Set Lokasi
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        checkPermissionsAndGetLocation()

        // Load History
        loadSavedData()

        btnFoto.setOnClickListener {
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            try { startActivityForResult(intent, REQ_CAMERA) } catch (e: Exception) {}
        }

        btnSimpan.setOnClickListener {
            val ket = etKet.text.toString()
            val loc = tvLoc.text.toString()

            if (ket.isEmpty()) {
                Toast.makeText(this, "Isi keterangan dulu!", Toast.LENGTH_SHORT).show()
            } else if (currentPhotoBitmap == null) {
                Toast.makeText(this, "Wajib ambil foto bukti!", Toast.LENGTH_SHORT).show()
            } else {
                saveData(ket, loc, currentPhotoBitmap!!)
                etKet.text.clear()
                ivPhoto.setImageResource(R.drawable.ic_launcher_background)
                currentPhotoBitmap = null
                container.removeAllViews()
                loadSavedData()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAMERA && resultCode == RESULT_OK) {
            val image = data?.extras?.get("data") as Bitmap
            currentPhotoBitmap = image
            ivPhoto.setImageBitmap(image)
        }
    }

    private fun saveData(keterangan: String, lokasi: String, bitmap: Bitmap) {
        val imagePath = saveImageToInternalStorage(bitmap)
        val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault())
        val tanggal = sdf.format(Date())
        val dataBaru = "$tanggal|$keterangan|$lokasi|$imagePath"

        val pref = getSharedPreferences("MANUAL_DATA", Context.MODE_PRIVATE)
        val oldData = pref.getString("LIST_DATA", "")
        val newData = if (oldData.isNullOrEmpty()) dataBaru else "$dataBaru;$oldData"
        pref.edit().putString("LIST_DATA", newData).apply()
    }

    private fun loadSavedData() {
        val pref = getSharedPreferences("MANUAL_DATA", Context.MODE_PRIVATE)
        val allData = pref.getString("LIST_DATA", "")
        if (!allData.isNullOrEmpty()) {
            val list = allData.split(";")
            for (item in list) {
                if (item.isNotEmpty()) {
                    val parts = item.split("|")
                    if (parts.size >= 4) {
                        addCardToView(parts[0], parts[1], parts[2], parts[3])
                    }
                }
            }
        }
    }

    private fun addCardToView(date: String, ket: String, loc: String, imgPath: String) {
        val view = LayoutInflater.from(this).inflate(R.layout.item_kehadiran_manual, container, false)
        view.findViewById<TextView>(R.id.tvItemTanggal).text = date
        view.findViewById<TextView>(R.id.tvItemKet).text = ket
        view.findViewById<TextView>(R.id.tvItemLokasi).text = loc
        val ivItem = view.findViewById<ImageView>(R.id.ivItemFoto)

        val imgFile = File(imgPath)
        if (imgFile.exists()) {
            ivItem.setImageBitmap(BitmapFactory.decodeFile(imgFile.absolutePath))
        }
        container.addView(view)
    }

    private fun saveImageToInternalStorage(bitmap: Bitmap): String {
        val wrapper = android.content.ContextWrapper(applicationContext)
        var file = wrapper.getDir("ManualImages", Context.MODE_PRIVATE)
        file = File(file, "manual_${System.currentTimeMillis()}.jpg")
        try {
            val stream: java.io.OutputStream = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
            stream.flush()
            stream.close()
        } catch (e: Exception) { e.printStackTrace() }
        return file.absolutePath
    }

    private fun checkPermissionsAndGetLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.CAMERA), REQ_PERMISSION)
        } else {
            getLocation()
        }
    }

    @SuppressLint("MissingPermission")
    private fun getLocation() {
        fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
            if (location != null) {
                val geocoder = Geocoder(this, Locale.getDefault())
                try {
                    val list = geocoder.getFromLocation(location.latitude, location.longitude, 1)
                    if (list != null && list.isNotEmpty()) {
                        tvLoc.text = list[0].getAddressLine(0)
                    } else {
                        tvLoc.text = "Lat: ${location.latitude}, Long: ${location.longitude}"
                    }
                } catch (e: Exception) { tvLoc.text = "Gagal memuat alamat" }
            } else { tvLoc.text = "Lokasi tidak ditemukan" }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMISSION && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            getLocation()
        }
    }
}
