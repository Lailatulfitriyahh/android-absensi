package com.example.lfitriyah018

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class OvertimeActivity : AppCompatActivity() {

    private lateinit var container: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_overtime)

        val tvDate = findViewById<TextView>(R.id.tvOvertimeDate)
        val etMulai = findViewById<EditText>(R.id.etJamMulai)
        val etSelesai = findViewById<EditText>(R.id.etJamSelesai)
        val etKet = findViewById<EditText>(R.id.etKeteranganLembur)
        val btnKirim = findViewById<Button>(R.id.btnKirimLembur)
        container = findViewById(R.id.containerOvertimeList)

        // 1. Set Tanggal Hari Ini
        val sdf = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id", "ID"))
        tvDate.text = sdf.format(Date())

        // 2. Load Data Lama
        loadData()

        // 3. Tombol Kirim
        btnKirim.setOnClickListener {
            val mulai = etMulai.text.toString()
            val selesai = etSelesai.text.toString()
            val ket = etKet.text.toString()

            if (mulai.isEmpty() || selesai.isEmpty() || ket.isEmpty()) {
                Toast.makeText(this, "Mohon lengkapi semua data!", Toast.LENGTH_SHORT).show()
            } else {
                saveData(mulai, selesai, ket)

                // Reset
                etMulai.text.clear()
                etSelesai.text.clear()
                etKet.text.clear()

                // Refresh
                container.removeAllViews()
                loadData()

                Toast.makeText(this, "Data Lembur Tersimpan!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveData(mulai: String, selesai: String, ket: String) {
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val tgl = sdf.format(Date())

        // Format: TANGGAL|MULAI|SELESAI|KETERANGAN
        val newData = "$tgl|$mulai|$selesai|$ket"

        val pref = getSharedPreferences("OVERTIME_DATA", Context.MODE_PRIVATE)
        val oldData = pref.getString("LIST_OVERTIME", "")

        val fixData = if (oldData.isNullOrEmpty()) newData else "$newData;$oldData"
        pref.edit().putString("LIST_OVERTIME", fixData).apply()
    }

    private fun loadData() {
        val pref = getSharedPreferences("OVERTIME_DATA", Context.MODE_PRIVATE)
        val allData = pref.getString("LIST_OVERTIME", "")

        if (!allData.isNullOrEmpty()) {
            val items = allData.split(";")
            for (item in items) {
                if (item.isNotEmpty()) {
                    val parts = item.split("|")
                    if (parts.size >= 4) {
                        val tgl = parts[0]
                        val mulai = parts[1]
                        val selesai = parts[2]
                        val ket = parts[3]

                        addCard(tgl, mulai, selesai, ket)
                    }
                }
            }
        }
    }

    private fun addCard(tgl: String, mulai: String, selesai: String, ket: String) {
        val view = LayoutInflater.from(this).inflate(R.layout.item_overtime, container, false)

        val tvTgl = view.findViewById<TextView>(R.id.tvItemOvertimeDate)
        val tvJam = view.findViewById<TextView>(R.id.tvItemOvertimeJam)
        val tvKet = view.findViewById<TextView>(R.id.tvItemOvertimeKet)

        tvTgl.text = tgl
        tvJam.text = "$mulai - $selesai"
        tvKet.text = ket

        container.addView(view)
    }
}
