package com.example.lfitriyah018

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*


class LaporanActivity : AppCompatActivity() {

    // View Components
    private lateinit var etJudul: EditText
    private lateinit var etProgress: EditText
    private lateinit var etKendala: EditText
    private lateinit var etSolusi: EditText
    private lateinit var etRencana: EditText
    private lateinit var tvNamaFile: TextView
    private lateinit var btnSimpan: Button
    private lateinit var btnBatalEdit: Button
    private lateinit var btnPilihFile: Button
    private lateinit var container: LinearLayout
    private lateinit var scrollView: ScrollView

    // Variables
    private val PICK_FILE_REQUEST = 1
    private var selectedFileUri: String = ""
    private var selectedFileName: String = ""

    // Mode Edit
    private var isEditMode = false
    private var editIndex = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_laporan)

        // Inisialisasi View
        scrollView = findViewById(R.id.scrollViewLaporan)
        etJudul = findViewById(R.id.etLaporanJudul)
        etProgress = findViewById(R.id.etLaporanProgress)
        etKendala = findViewById(R.id.etLaporanKendala)
        etSolusi = findViewById(R.id.etLaporanSolusi)
        etRencana = findViewById(R.id.etLaporanRencana)
        tvNamaFile = findViewById(R.id.tvNamaFile)
        btnSimpan = findViewById(R.id.btnSimpanLaporan)
        btnBatalEdit = findViewById(R.id.btnBatalEdit)
        btnPilihFile = findViewById(R.id.btnPilihFile)
        container = findViewById(R.id.containerLaporan)

        // 1. Pilih File
        btnPilihFile.setOnClickListener { openFilePicker() }

        // 2. Load Data saat dibuka
        loadData()

        // 3. Simpan / Update
        btnSimpan.setOnClickListener { simpanLaporan() }

        // 4. Batal Edit
        btnBatalEdit.setOnClickListener { resetForm() }
    }

    private fun openFilePicker() {
        // Menggunakan ACTION_OPEN_DOCUMENT agar URI bersifat persisten (bisa dibuka jangka panjang)
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            val mimeTypes = arrayOf(
                "application/pdf",
                "application/msword",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "image/jpeg",
                "image/png"
            )
            putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
        }
        startActivityForResult(intent, PICK_FILE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE_REQUEST && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->

                // PENTING: Ambil izin agar file bisa dibaca terus (Persistable Permission)
                try {
                    val takeFlags: Int = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    contentResolver.takePersistableUriPermission(uri, takeFlags)
                } catch (e: Exception) {
                    e.printStackTrace()
                }

                selectedFileUri = uri.toString()
                selectedFileName = getFileName(uri)
                tvNamaFile.text = selectedFileName
            }
        }
    }

    private fun getFileName(uri: Uri): String {
        var result: String? = null
        if (uri.scheme == "content") {
            val cursor = contentResolver.query(uri, null, null, null, null)
            cursor.use {
                if (it != null && it.moveToFirst()) {
                    val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if(index != -1) result = it.getString(index)
                }
            }
        }
        if (result == null) {
            result = uri.path
            val cut = result?.lastIndexOf('/')
            if (cut != -1) result = result?.substring(cut!! + 1)
        }
        return result ?: "File"
    }

    private fun simpanLaporan() {
        val judul = etJudul.text.toString()
        val progress = etProgress.text.toString()
        val kendala = etKendala.text.toString()
        val solusi = etSolusi.text.toString()
        val rencana = etRencana.text.toString()

        if (judul.isEmpty() || progress.isEmpty()) {
            Toast.makeText(this, "Judul dan Progress wajib diisi!", Toast.LENGTH_SHORT).show()
            return
        }

        val sdf = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val tanggal = sdf.format(Date())

        // Format simpan: JUDUL|PROGRESS|KENDALA|SOLUSI|RENCANA|NAMAFILE|URIFILE|TANGGAL
        val dataString = "$judul|$progress|$kendala|$solusi|$rencana|$selectedFileName|$selectedFileUri|$tanggal"

        val pref = getSharedPreferences("LAPORAN_DB", Context.MODE_PRIVATE)
        val oldDataString = pref.getString("LIST_LAPORAN", "")

        var listData = if (oldDataString.isNullOrEmpty()) mutableListOf() else oldDataString.split(";;;").toMutableList()

        if (isEditMode && editIndex != -1) {
            // Update Data Lama
            listData[editIndex] = dataString
            Toast.makeText(this, "Data Berhasil Diperbarui!", Toast.LENGTH_SHORT).show()
        } else {
            // Buat Data Baru (Di paling atas)
            listData.add(0, dataString)
            Toast.makeText(this, "Data Berhasil Disimpan!", Toast.LENGTH_SHORT).show()
        }

        // Simpan ke HP
        val newDataString = listData.joinToString(";;;")
        pref.edit().putString("LIST_LAPORAN", newDataString).apply()

        resetForm()
        loadData()
    }

    private fun resetForm() {
        etJudul.text.clear()
        etProgress.text.clear()
        etKendala.text.clear()
        etSolusi.text.clear()
        etRencana.text.clear()
        tvNamaFile.text = "Pilih File (PDF, Word, Excel)"
        selectedFileUri = ""
        selectedFileName = ""

        isEditMode = false
        editIndex = -1
        btnSimpan.text = "Simpan Laporan"
        btnBatalEdit.visibility = View.GONE
    }

    private fun loadData() {
        container.removeAllViews()
        val pref = getSharedPreferences("LAPORAN_DB", Context.MODE_PRIVATE)
        val allDataString = pref.getString("LIST_LAPORAN", "")

        if (!allDataString.isNullOrEmpty()) {
            val listData = allDataString.split(";;;")
            for ((index, item) in listData.withIndex()) {
                if (item.isNotEmpty()) {
                    val parts = item.split("|")
                    if (parts.size >= 8) {
                        tampilkanItem(index, parts)
                    }
                }
            }
        }
    }

    private fun tampilkanItem(index: Int, parts: List<String>) {
        val view =
            LayoutInflater.from(this).inflate(R.layout.item_laporan, container, false)

        val tvJudul = view.findViewById<TextView>(R.id.tvItemJudul)
        val tvTgl = view.findViewById<TextView>(R.id.tvItemTanggal)
        val tvIsi = view.findViewById<TextView>(R.id.tvItemIsiLaporan)
        val tvFile = view.findViewById<TextView>(R.id.tvItemNamaFile)
        val layoutFile = view.findViewById<LinearLayout>(R.id.layoutFileAttachment)

        val btnEdit = view.findViewById<TextView>(R.id.btnEditLaporan)
        val btnHapus = view.findViewById<TextView>(R.id.btnHapusLaporan)

        // Ambil Data
        val judul = parts[0]
        val progress = parts[1]
        val kendala = parts[2]
        val solusi = parts[3]
        val rencana = parts[4]
        val namaFile = parts[5]
        val uriString = parts[6] // URI File
        val tgl = parts[7]

        // Set Text
        tvJudul.text = judul
        tvTgl.text = tgl.split(" ")[0]

        val isiLaporan = StringBuilder()
        isiLaporan.append("Progress: $progress%\n")
        if (kendala.isNotEmpty()) isiLaporan.append("Kendala: $kendala\n")
        if (solusi.isNotEmpty()) isiLaporan.append("Solusi: $solusi\n")
        if (rencana.isNotEmpty()) isiLaporan.append("Rencana: $rencana")

        tvIsi.text = isiLaporan.toString()

        // --- FITUR BUKA FILE ---
        if (namaFile.isNotEmpty() && uriString.isNotEmpty()) {
            tvFile.text = "📎 $namaFile (Klik untuk Buka)"
            layoutFile.visibility = View.VISIBLE

            // Saat container file diklik, buka file-nya
            layoutFile.setOnClickListener {
                bukaFile(uriString)
            }
        } else {
            layoutFile.visibility = View.GONE
        }

        // --- AKSI TOMBOL ---
        btnEdit.setOnClickListener {
            isiFormUntukEdit(index, parts)
        }

        btnHapus.setOnClickListener {
            hapusLaporan(index)
        }

        container.addView(view)
    }

    // FUNGSI UNTUK MEMBUKA FILE
    private fun bukaFile(uriString: String) {
        try {
            val uri = Uri.parse(uriString)
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = uri
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)

            // Coba buka dengan aplikasi pembaca (PDF/Office Viewer)
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Tidak ada aplikasi untuk membuka file ini", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuka file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isiFormUntukEdit(index: Int, parts: List<String>) {
        scrollView.fullScroll(ScrollView.FOCUS_UP)

        etJudul.setText(parts[0])
        etProgress.setText(parts[1])
        etKendala.setText(parts[2])
        etSolusi.setText(parts[3])
        etRencana.setText(parts[4])

        selectedFileName = parts[5]
        selectedFileUri = parts[6]

        if (selectedFileName.isNotEmpty()) {
            tvNamaFile.text = selectedFileName
        } else {
            tvNamaFile.text = "Tidak ada file sebelumnya"
        }

        isEditMode = true
        editIndex = index
        btnSimpan.text = "Update Laporan"
        btnBatalEdit.visibility = View.VISIBLE

        Toast.makeText(this, "Silakan Edit Data Di Atas", Toast.LENGTH_SHORT).show()
    }

    private fun hapusLaporan(index: Int) {
        val pref = getSharedPreferences("LAPORAN_DB", Context.MODE_PRIVATE)
        val allDataString = pref.getString("LIST_LAPORAN", "")

        if (!allDataString.isNullOrEmpty()) {
            val listData = allDataString.split(";;;").toMutableList()
            if (index >= 0 && index < listData.size) {
                listData.removeAt(index)

                val newDataString = listData.joinToString(";;;")
                pref.edit().putString("LIST_LAPORAN", newDataString).apply()

                loadData()
                Toast.makeText(this, "Laporan Dihapus", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
