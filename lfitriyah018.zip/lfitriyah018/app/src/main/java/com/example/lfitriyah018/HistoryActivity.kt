package com.example.lfitriyah018

import android.content.Context // <--- INI YANG BENAR
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File


class HistoryActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val container = findViewById<LinearLayout>(R.id.containerHistory)

        // 1. Ambil Data
        val sharedPref = getSharedPreferences("HISTORY_ABSEN", Context.MODE_PRIVATE)
        val allDataString = sharedPref.getString("LIST_HISTORY", "")

        if (allDataString.isNullOrEmpty()) return

        // 2. Pecah Data
        val listData = allDataString.split(";")

        for (item in listData) {
            if (item.isNotEmpty()) {
                val details = item.split("|")
                if (details.size >= 5) {
                    val tanggal = details[0]
                    val jam = details[1]
                    val tipe = details[2]
                    val lokasi = details[3]
                    val imagePath = details[4]

                    // 3. Tampilkan Item
                    val itemView = LayoutInflater.from(this).inflate(R.layout.item_history, container, false)

                    val tvStatus = itemView.findViewById<TextView>(R.id.tvHistoryStatus)
                    val tvDate = itemView.findViewById<TextView>(R.id.tvHistoryDate)
                    val tvLoc = itemView.findViewById<TextView>(R.id.tvHistoryLocation)
                    val ivPhoto = itemView.findViewById<ImageView>(R.id.ivHistoryPhoto)

                    tvStatus.text = "Absen $tipe"
                    tvDate.text = "$tanggal, $jam"
                    tvLoc.text = lokasi

                    val imgFile = File(imagePath)
                    if (imgFile.exists()) {
                        val myBitmap = BitmapFactory.decodeFile(imgFile.absolutePath)
                        ivPhoto.setImageBitmap(myBitmap)
                    }

                    container.addView(itemView)
                }
            }
        }
    }
}
