package com.example.lfitriyah018

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.lfitriyah018.databinding.ActivityDashboardBinding
import java.text.SimpleDateFormat
import java.util.*

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding
    private val handler = Handler(Looper.getMainLooper())

    // Variabel untuk Edit Profil
    private val PICK_IMAGE_REQUEST = 100
    private var tempImageUri: Uri? = null
    private var ivDialogProfile: ImageView? = null

    private val updateTimeRunnable = object : Runnable {
        override fun run() {
            updateTimeAndDate()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load data profil tersimpan
        loadProfileData()

        setupMenuActions()

        // KLIK PROFIL (Pojok Kanan Atas)
        binding.cardProfile.setOnClickListener {
            showEditProfileDialog()
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(updateTimeRunnable)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(updateTimeRunnable)
    }

    private fun updateTimeAndDate() {
        val calendar = Calendar.getInstance()
        val dateFormat = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id", "ID"))
        val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

        binding.tvDate.text = dateFormat.format(calendar.time)
        binding.tvTime.text = timeFormat.format(calendar.time)
    }

    // --- LOGIKA EDIT PROFIL ---

    private fun showEditProfileDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_profile, null)
        val builder = AlertDialog.Builder(this)
        builder.setView(dialogView)
        val dialog = builder.create()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        val etNama = dialogView.findViewById<EditText>(R.id.etEditNama)
        val btnSimpan = dialogView.findViewById<Button>(R.id.btnSimpanProfil)
        val btnGantiFoto = dialogView.findViewById<TextView>(R.id.btnGantiFoto)
        ivDialogProfile = dialogView.findViewById(R.id.ivEditProfile)

        // Isi nama saat ini
        val pref = getSharedPreferences("USER_PREF", Context.MODE_PRIVATE)
        etNama.setText(pref.getString("USER_NAME", "Min Yoongi"))

        // Tampilkan foto saat ini
        val savedUriString = pref.getString("USER_PHOTO", "")
        if (!savedUriString.isNullOrEmpty()) {
            try {
                ivDialogProfile?.setImageURI(Uri.parse(savedUriString))
            } catch (e: Exception) {
                ivDialogProfile?.setImageResource(R.drawable.ic_launcher_background)
            }
        }

        // Aksi Ganti Foto
        btnGantiFoto.setOnClickListener { openGallery() }

        // Aksi Simpan
        btnSimpan.setOnClickListener {
            val newName = etNama.text.toString()
            if (newName.isNotEmpty()) {
                saveProfile(newName)
                dialog.dismiss()
            } else {
                Toast.makeText(this, "Nama tidak boleh kosong", Toast.LENGTH_SHORT).show()
            }
        }

        dialog.show()
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "image/*"
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                try {
                    val takeFlags: Int = Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    contentResolver.takePersistableUriPermission(uri, takeFlags)
                } catch (e: Exception) { e.printStackTrace() }

                tempImageUri = uri
                ivDialogProfile?.setImageURI(uri)
            }
        }
    }

    private fun saveProfile(name: String) {
        val pref = getSharedPreferences("USER_PREF", Context.MODE_PRIVATE)
        val editor = pref.edit()
        editor.putString("USER_NAME", name)
        if (tempImageUri != null) {
            editor.putString("USER_PHOTO", tempImageUri.toString())
        }
        editor.apply()
        loadProfileData()
        Toast.makeText(this, "Profil Diperbarui!", Toast.LENGTH_SHORT).show()
    }

    private fun loadProfileData() {
        val pref = getSharedPreferences("USER_PREF", Context.MODE_PRIVATE)
        val name = pref.getString("USER_NAME", "Min Yoongi")
        val photoUriString = pref.getString("USER_PHOTO", "")

        binding.tvUserName.text = name
        if (!photoUriString.isNullOrEmpty()) {
            try {
                binding.ivProfile.setImageURI(Uri.parse(photoUriString))
            } catch (e: Exception) {
                binding.ivProfile.setImageResource(R.drawable.ic_launcher_background)
            }
        }
    }

    // --- MENU ACTIONS ---
    private fun setupMenuActions() {
        // --- FITUR DAFTAR KEHADIRAN (UTAMA) ---
        // Catatan: Pastikan nama kelas Activity Anda sesuai (KehadiranManualActivity atau KehadiranActivity)
        binding.menuKehadiran.setOnClickListener {
            startActivity(Intent(this, KehadiranManualActivity::class.java))
        }

        // --- MENU LAINNYA ---
        binding.boxIn.setOnClickListener {
            val intent = Intent(this, AbsenActivity::class.java)
            intent.putExtra("IS_CHECK_IN", true)
            startActivity(intent)
        }
        binding.boxOut.setOnClickListener {
            val intent = Intent(this, AbsenActivity::class.java)
            intent.putExtra("IS_CHECK_IN", false)
            startActivity(intent)
        }

        binding.menuHistory.setOnClickListener { startActivity(Intent(this, HistoryActivity::class.java)) }
        binding.menuIzin.setOnClickListener { startActivity(Intent(this, IzinActivity::class.java)) }
        binding.menuJamKerja.setOnClickListener { startActivity(Intent(this, JamKerjaActivity::class.java)) }
        binding.menuLaporan.setOnClickListener { startActivity(Intent(this, LaporanActivity::class.java)) }
        binding.menuCuti.setOnClickListener { startActivity(Intent(this, CutiActivity::class.java)) }
        binding.menuOvertime.setOnClickListener { startActivity(Intent(this, OvertimeActivity::class.java)) }

        // --- REKAP BULANAN (YANG BARU DITAMBAHKAN) ---
        binding.menuRekap.setOnClickListener {
            val intent = Intent(this, RekapActivity::class.java)
            startActivity(intent)
        }

        // Social Media & Maps
        binding.menuFacebook.setOnClickListener {
            val url = "https://www.facebook.com/akuu.ftr"
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
        binding.menuInstagram.setOnClickListener {
            val url = "https://www.instagram.com/ilkom_uniwara"
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
        binding.menuMaps.setOnClickListener {
            val uri = Uri.parse("geo:-7.657788,112.911417?q=Universitas PGRI Wiranegara")
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        }
    }
}
