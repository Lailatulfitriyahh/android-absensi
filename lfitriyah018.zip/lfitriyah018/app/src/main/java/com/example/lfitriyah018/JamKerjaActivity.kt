package com.example.lfitriyah018

import android.os.Bundle
import android.widget.CalendarView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class JamKerjaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_jam_kerja)

        // Opsional: Jika user iseng klik tanggal di kalender
        val calendarView = findViewById<CalendarView>(R.id.calendarView)

        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            // Bulan dimulai dari 0 (Januari = 0)
            val selectedDate = "$dayOfMonth/${month + 1}/$year"
            Toast.makeText(this, "Tanggal terpilih: $selectedDate", Toast.LENGTH_SHORT).show()
        }
    }
}
